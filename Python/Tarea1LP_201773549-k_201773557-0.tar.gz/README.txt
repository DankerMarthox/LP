Nombre: 			ROL

Ian Pérez Santis		201773549-K
Martín Salinas Scussolin	201773557-0


Instrucciones de uso:

Es un archivo de python... so... ejecutar?

Basically:

	Para cumplir con las básicas, primero, asegurese de estar respirando, pestañeando, y que su lengua esté comoda dentro de su boca.
	Ahora que posiblemente esté respirando y pestañeando manualmente (y, quizas moviendo un poquito la lengua por alguna razón), está listo para continuar.


	IMPORTANTE: Tomese un minuto para apreciar la belleza de Comic Sans.


	Si está leyendo esto, significa que posiblemente descomprimió el archivo y además inició correctamente sesión en su computador sin olvidar la contraseña
	(intro 2017) ;D .  (by martín)

	En caso de que no haya descomprimido el archivo, por favor descomprimalo y vuelva a consultar esta guía.

	Ahora, asegurese de tener Python instalado correctamente en su computador, (ya sea este x86 o x64).
	Puede verificar esto ingresando así:
		Windows:  "Panel de Control"->"Agregar o quitar programas", y busque Python en la lista que se mostrará a continuación.
		Linux: ingrese "python3 -V" en la consola. Si imprime muchas cosas raras, está funcionando correctamente

	En caso de que no tenga python instalado, inicie su navegador de preferencia, ingrese a www.google.cl, y busque "Python 3"
	Instalelo acorde a su sistema operativo. Si no sabe cual es, reinicie su computadora, y, cuando este inicie nuevamente mostrará el logo de su sistema operativo (En la mayoria de los casos).

	Ahora puede continuar con la ejecución del programa.
	Para esto debe:


	Tener "translatext.py" y "pseudocode.txt" en la misma carpeta

	Opcion 1:
		Hacer dobleclick al programa
		Abrir el archivo resultante
		Leer el archivo resultante

	Opcion 2:
		Abrir la consola
			* En Windows: en el buscador ingrese "CMD" y presione ENTER. Cuando la consola se abra, localice el archivo utilizando el comando "cd (direccion)"
			* En Linux: Lo mismo, pero la terminal se puede abrir con click derecho.

		Escriba el comando PATH de python (Este puede variar entre "python" o "python3", en otros casos dependerá de como está guardado. Puede revisarse en los ajustes del sistema
		operativo bajo el nombre de "Variables de Entorno")		



	Si el programa se ejecutó correctamente, proceda a revisar el anexo al termino de este archivo.

























Anexo:





	Dab



C U L8R Boi
