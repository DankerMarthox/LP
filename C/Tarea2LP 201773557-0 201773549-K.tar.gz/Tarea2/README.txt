
						(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)
		(ﾉ◕ヮ◕)ﾉ*  PANTUFLA, YOUR NEXT LINE WILL BE MIRA EL OTAKU QLO   *ヽ(◕ヮ◕ヽ)

Nombre: 			ROL

Ian Pérez Santis		201773549-K
Martín Salinas Scussolin	201773557-0

						(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)

Instrucciones de uso:

	* Se compila usando make (escribir en la consola: make)
	  luego, ejecutar usando el comando: ./main
	* Es necesario tener el archivo cartas.txt en la misma carpeta con todos los demas 
	  archivos *dab*

						(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)

Basically:

	* Por favor, intentar por todos los medios posibles ejecutar el programa con un archivo llamado 
	  cartas.txt cerca de main.c.
	* Si quieres sufrir (y suponiendo que tengas R.A.M. suficiente), te recomiendo ejecutar el programa
	  sin ningun archivo *da-dab*
	
	
	
						(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)

























Anexo:
esta al reves boi

*qǝǝʍ uı sqɐp-ɐpɐp-ɐp-ɐp*
˙opɐpınɔ uoɔ ǝpǝɔoɹԀ ˙soıɔɐʌ soʌıɥɔɹɐ 008 ǝp ɹopǝpǝɹʃɐ uɐɹɐǝɹɔ ǝʇ ǝs 
'ɹǝǝʃ ǝnb oʌıɥɔɹɐ un uıs ɐɯɐɹƃoɹd ʃǝ sɐʇnɔǝɾǝ ıs
˙nɹıǝpuıɥs noɯ ɐʍ ǝɐɯo

