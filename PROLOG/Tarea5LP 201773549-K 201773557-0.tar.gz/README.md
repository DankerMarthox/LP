
						(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)

						*da-dabs bc gg ez tarea 5*

Nombre: 			ROL

Ian Pérez Santis			201773549-K
Martín Salinas Scussolin	201773557-0

						(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)

Instrucciones de uso:

	* Se corre en swi-prolog (online) (y si no, mal ahí, por qué instalar tonteras?)
	* Es necesario saber prolog para correr el archivo

						(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)

Basically:

	* Por favor, intentar por todos los medios posibles ejecutar el programa como corresponda.	
	
	
						(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)

























Anexo:
esta al reves boi

*qǝǝʍ uı sqɐp-ɐpɐp-ɐp-ɐp*
˙opɐpınɔ uoɔ ǝpǝɔoɹԀ ˙soıɔɐʌ soʌıɥɔɹɐ 0008 ǝp ɹopǝpǝɹʃɐ uɐɹɐǝɹɔ ǝʇ ǝs 
'ɹǝǝʃ ǝnb oʌıɥɔɹɐ un uıs ɐɯɐɹƃoɹd ʃǝ sɐʇnɔǝɾǝ ıs
˙nɹıǝpuıɥs noɯ ɐʍ ǝɐɯo
